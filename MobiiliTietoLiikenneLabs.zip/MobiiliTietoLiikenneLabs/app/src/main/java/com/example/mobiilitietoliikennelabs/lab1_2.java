package com.example.mobiilitietoliikennelabs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class lab1_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab1_2);
        /*
        Empty, because were using lab1_1.java as it has the same functionality now we only add geocoder.
         */
    }
}
